import requests
url ="https://192.168.30.141/api/storage/uploadfile?client=300000000000000000000005"
headers = {'content-type': "application/json"}
try:
    response = requests.request("GET", url, headers=headers)
    print ("----",response)
except Exception as e:
    print (e)


