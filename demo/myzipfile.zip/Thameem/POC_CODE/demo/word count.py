from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import Counter
import re,string

exclude = set(string.punctuation)
print (exclude)
file = open(r"info.txt", "r")
# doc = re.sub(r"[(\[\]),;:\.]", "", file.read())
stop_words = set(stopwords.words('english'))
print(stop_words)
word_tokens = word_tokenize(file.read())
wordcount = Counter(word_tokens)
print(wordcount)
filtered_sentence = [w for w in word_tokens if not w in stop_words and not w in exclude]

wordcount = Counter(filtered_sentence)
print(wordcount)
first3pairs =[word for word,cnt in wordcount.most_common(3)]
print(first3pairs)