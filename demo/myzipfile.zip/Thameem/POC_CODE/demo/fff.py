import traceback
def _tcp_proc(self, addrinfo, task=None):
    """
    Internal use only.
    """
    task.set_daemon()
    sock = addrinfo.tcp_sock
    while 1:
        try:
            conn, addr = yield sock.accept()
        except ssl.SSLError as err:
            print(str(traceback.format_exc()))
            logger.debug('SSL connection failed: %s', str(err))
            continue
        except GeneratorExit:
            break
        except:
            logger.debug(traceback.format_exc())
            print(str(traceback.format_exc()))

        SysTask(self._tcp_conn_proc, conn, addrinfo)