import re
import ast

file = open('info.txt', 'r', encoding="utf8").readlines()
lst = ["".join(file)]
lst = re.sub("\"","",lst)
print(lst)
